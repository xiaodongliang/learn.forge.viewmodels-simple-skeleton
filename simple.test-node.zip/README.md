# learn.forge.viewmodels-simple-skeleton
a test harness forked from https://github.com/Autodesk-Forge/learn.forge.viewmodels

This test harness is based on the tutorial http://learnforge.autodesk.io/#/, but with more simpler client, in order to help to understand the unit test of Forge API.

Switch to the corresponding language to test.
